int sec_gps_conf(void)
{
    return 0;
}

int Sec_Configuration(void)
{
    return 0;
}
